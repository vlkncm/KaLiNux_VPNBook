#!/usr/bin/env python3
"""Small GTK client for NetworkManager OpenVPN profiles. No stored passwords."""
import os
import re
import shutil
import subprocess
import threading
from pathlib import Path

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

PREFIX = 'VPNBook • '
ENV = dict(os.environ, LC_ALL='C')


def nm(*args, pass_fds=()):
    result = subprocess.run(['nmcli', '--wait', '90', *args], env=ENV,
                            capture_output=True, text=True, timeout=100,
                            pass_fds=pass_fds)
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout).strip())
    return result.stdout.strip()


def profiles():
    rows = nm('-t', '--escape', 'no', '-f', 'UUID,TYPE,NAME', 'connection', 'show')
    found = []
    for row in rows.splitlines():
        parts = row.split(':', 2)
        if len(parts) == 3 and parts[1] == 'vpn' and parts[2].startswith(PREFIX):
            found.append((parts[0], parts[2][len(PREFIX):]))
    return found


def connect(profile, username, password):
    if any(c in username + password for c in '\r\n\x00'):
        raise ValueError('Kullanıcı adı ve şifre satır sonu içeremez.')
    # vpn.user-name avoids embedding user input in the comma-separated data map.
    nm('connection', 'modify', 'uuid', profile, 'vpn.user-name', username,
       '+vpn.data', 'password-flags=2', 'vpn.secrets', '')
    # Linux anonymous memory file: secret is neither on disk nor in argv/env.
    fd = os.memfd_create('vpn-password', flags=os.MFD_CLOEXEC)
    try:
        os.write(fd, ('vpn.secrets.password:' + password + '\n').encode())
        os.lseek(fd, 0, os.SEEK_SET)
        nm('connection', 'up', 'uuid', profile, 'passwd-file',
           '/proc/self/fd/' + str(fd), pass_fds=(fd,))
    finally:
        os.close(fd)


def connect_next(rows, selected, username, password, notify):
    """Try each imported profile once; stop at first successful activation."""
    if any(c in username + password for c in '\r\n\x00'):
        raise ValueError('Kullanıcı adı ve şifre satır sonu içeremez.')
    unique = dict(rows)
    if selected not in unique:
        raise ValueError('Önce bir profil seçin.')
    order = [(selected, unique.pop(selected)), *unique.items()]
    failures = []
    for index, (uid, name) in enumerate(order, 1):
        notify(f'{index}/{len(order)} — {name} deneniyor…')
        try:
            connect(uid, username, password)
            return uid, name
        except Exception as exc:
            # Stop any activation that could otherwise complete after its timeout.
            try:
                nm('connection', 'down', 'uuid', uid)
            except Exception:
                pass
            active = nm('-g', 'UUID', 'connection', 'show', '--active').splitlines()
            if uid in active:
                raise RuntimeError('Önceki VPN denemesi kapatılamadı. Sistem ağ ayarlarından bağlantıyı kesin.')
            detail = str(exc).replace(password, '[gizli]') if password else str(exc)
            failures.append(name + ': ' + detail)
    raise RuntimeError('Hiçbir profile bağlanılamadı. Kullanıcı adı/şifreyi ve internet bağlantısını kontrol edin.\n\n' + '\n'.join(failures))


class Window(Gtk.Window):
    def __init__(self):
        super().__init__(title='VPNBook | Kali')
        self.set_default_size(620, 530)
        self.set_border_width(26)
        self.busy = False
        self.polling = False
        self.connect('delete-event', self.close)
        css = Gtk.CssProvider()
        css.load_from_data(b'window {background:#111827;color:#e5e7eb;} label {color:#e5e7eb;} entry, combobox button {background:#1f2937;color:#f9fafb;border-color:#374151;min-height:30px;} button {background:#283548;color:#f9fafb;border-radius:7px;padding:8px;} button.suggested-action {background:#087f8c;} textview text {background:#192231;color:#d1d5db;}')
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css,
                                                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.add(box)
        title = Gtk.Label(xalign=0)
        title.set_markup('<span size="24000" weight="bold">VPNBook</span>  /  Kali Linux')
        box.pack_start(title, False, False, 0)
        box.pack_start(Gtk.Label(label='OVPN profilini ekle. Bilgilerini gir. Bağlan.', xalign=0), False, False, 0)
        link = Gtk.LinkButton.new_with_label(
            'https://www.vpnbook.com/tr/freevpn/openvpn',
            'VPNBook — kullanıcı adı, şifre ve OVPN dosyaları')
        link.set_halign(Gtk.Align.START)
        box.pack_start(link, False, False, 0)
        self.status = Gtk.Label(label='Durum kontrol ediliyor…', xalign=0)
        box.pack_start(self.status, False, False, 0)
        self.combo = Gtk.ComboBoxText()
        box.pack_start(self.combo, False, False, 0)
        self.buttons = []
        line = Gtk.Box(spacing=8)
        box.pack_start(line, False, False, 0)
        self.button(line, 'OVPN dosyası ekle', self.import_files)
        self.button(line, 'Profilleri yenile', lambda *_: self.load())
        self.user = Gtk.Entry()
        self.user.set_placeholder_text('Kullanıcı adı')
        box.pack_start(self.user, False, False, 0)
        self.password = Gtk.Entry()
        self.password.set_placeholder_text('Şifre (kaydedilmez)')
        self.password.set_visibility(False)
        self.password.set_input_purpose(Gtk.InputPurpose.PASSWORD)
        self.password.connect('activate', self.up)
        box.pack_start(self.password, False, False, 0)
        show = Gtk.CheckButton(label='Şifreyi göster')
        show.connect('toggled', lambda w: self.password.set_visibility(w.get_active()))
        box.pack_start(show, False, False, 0)
        line = Gtk.Box(spacing=8)
        box.pack_start(line, False, False, 0)
        self.button(line, 'Bağlan', self.up, True)
        self.button(line, 'Bağlantıyı kes', self.down)
        scroll = Gtk.ScrolledWindow()
        scroll.set_min_content_height(100)
        self.log = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.WORD_CHAR)
        scroll.add(self.log)
        box.pack_start(scroll, True, True, 0)
        note = Gtk.Label(label='Pencereyi kapatmak VPN bağlantısını kesmez.', xalign=0)
        box.pack_start(note, False, False, 0)
        self.show_all()
        if not shutil.which('nmcli'):
            self.message('NetworkManager bulunamadı. Önce Kur.sh dosyasını çalıştırın.')
            for b in self.buttons:
                b.set_sensitive(False)
        else:
            self.load()
        GLib.timeout_add_seconds(4, self.poll)

    def button(self, box, title, handler, suggested=False):
        b = Gtk.Button(label=title)
        if suggested:
            b.get_style_context().add_class('suggested-action')
        b.connect('clicked', handler)
        box.pack_start(b, True, True, 0)
        self.buttons.append(b)

    def message(self, text):
        self.log.get_buffer().set_text(text)

    def run(self, task, done=None):
        if self.busy:
            return
        self.busy = True
        self.combo.set_sensitive(False)
        for b in self.buttons:
            b.set_sensitive(False)
        self.status.set_text('İşlem sürüyor…')

        def worker():
            try:
                result = task()
                error = None
            except Exception as exc:
                result, error = None, str(exc)
            GLib.idle_add(finish, result, error)

        def finish(result, error):
            self.busy = False
            self.combo.set_sensitive(True)
            for b in self.buttons:
                b.set_sensitive(True)
            if error:
                self.message('İşlem tamamlanamadı.\n' + error + '\n\nŞifreyi, internet bağlantısını ve profilin güncelliğini kontrol edin. Yetki hatasında normal masaüstü oturumunda çalıştırın.')
            elif done:
                done(result)
            self.poll()
            return False

        threading.Thread(target=worker, daemon=True).start()

    def load(self):
        old = self.combo.get_active_id()
        def done(rows):
            self.combo.remove_all()
            for uid, name in rows:
                self.combo.append(uid, name)
            if not old or not self.combo.set_active_id(old):
                self.combo.set_active(0)
            if not rows:
                self.message('Başlamak için OVPN dosyası ekle düğmesine basın. Yalnızca güvenilir kaynaktan indirdiğiniz profilleri kullanın.')
        self.run(profiles, done)

    def import_files(self, *_):
        dialog = Gtk.FileChooserDialog(title='OVPN dosyalarını seç', parent=self,
                                     action=Gtk.FileChooserAction.OPEN)
        dialog.add_buttons('Vazgeç', Gtk.ResponseType.CANCEL, 'Ekle', Gtk.ResponseType.OK)
        dialog.set_select_multiple(True)
        filt = Gtk.FileFilter()
        filt.set_name('OpenVPN (*.ovpn)')
        filt.add_pattern('*.ovpn')
        dialog.add_filter(filt)
        response = dialog.run()
        files = dialog.get_filenames() if response == Gtk.ResponseType.OK else []
        dialog.destroy()
        if not files:
            return

        def task():
            report = []
            for filename in files:
                uid = None
                try:
                    output = nm('connection', 'import', 'type', 'openvpn', 'file', filename)
                    match = re.search(r'\b[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b', output)
                    if not match:
                        raise RuntimeError('İçe aktarılan profil kimliği okunamadı: ' + output)
                    uid = match.group(0)
                    nm('connection', 'modify', 'uuid', uid, 'connection.id',
                       PREFIX + Path(filename).stem, 'connection.autoconnect', 'no',
                       'connection.permissions', 'user:' + __import__('getpass').getuser(),
                       '+vpn.data', 'password-flags=2', 'vpn.secrets', '')
                    report.append(Path(filename).name + ': eklendi')
                except Exception as exc:
                    if uid:
                        try:
                            nm('connection', 'delete', 'uuid', uid)
                        except Exception:
                            pass
                    report.append(Path(filename).name + ': ' + str(exc))
            return '\n'.join(report), profiles()

        def done(result):
            report, rows = result
            self.combo.remove_all()
            for uid, name in rows:
                self.combo.append(uid, name)
            self.combo.set_active(0)
            self.message(report)
        self.run(task, done)

    def up(self, *_):
        if self.busy:
            return
        uid = self.combo.get_active_id()
        username, password = self.user.get_text().strip(), self.password.get_text()
        if not uid or not username or not password:
            self.message('Profil seçin; kullanıcı adını ve şifreyi doldurun.')
            return
        model = self.combo.get_model()
        id_column = self.combo.get_id_column()
        text_column = self.combo.get_entry_text_column()
        rows = [(row[id_column], row[text_column]) for row in model]
        def progress(text):
            def update():
                self.status.set_text(text)
                self.message(text + '\nBağlanamazsa sıradaki profil otomatik denenecek.')
                return False
            GLib.idle_add(update)
        def done(result):
            connected_uid, name = result
            self.combo.set_active_id(connected_uid)
            self.password.set_text('')
            self.message(name + ' profiline bağlanıldı. Şifre alanı temizlendi.')
        self.run(lambda: connect_next(rows, uid, username, password, progress), done)

    def down(self, *_):
        uid = self.combo.get_active_id()
        if uid:
            self.run(lambda: nm('connection', 'down', 'uuid', uid),
                     lambda _: self.message('Seçili VPN bağlantısı kesildi.'))

    def poll(self):
        if self.busy or self.polling or not shutil.which('nmcli'):
            return True
        self.polling = True
        uid = self.combo.get_active_id()
        def worker():
            try:
                active = nm('-g', 'UUID', 'connection', 'show', '--active').splitlines()
                status = '● Seçili VPN bağlı' if uid in active else '○ Seçili VPN bağlı değil'
            except Exception:
                status = 'Durum okunamadı — NetworkManager hizmetini kontrol edin'
            GLib.idle_add(finish, status)
        def finish(status):
            if not self.busy and uid == self.combo.get_active_id():
                self.status.set_text(status)
            self.polling = False
            return False
        threading.Thread(target=worker, daemon=True).start()
        return True

    def close(self, *_):
        if self.busy:
            self.message('İşlem devam ediyor. Tamamlandıktan sonra pencereyi kapatabilirsiniz.')
            return True
        Gtk.main_quit()
        return False


if __name__ == '__main__':
    Window()
    Gtk.main()
