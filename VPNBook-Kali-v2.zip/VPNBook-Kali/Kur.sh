#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [ "$(id -u)" -eq 0 ]; then
  echo 'Bu dosyayı normal kullanıcı olarak çalıştırın. Gerektiğinde sudo şifreniz sorulacak.'
  exit 1
fi
sudo apt-get update
sudo apt-get install -y python3 python3-gi gir1.2-gtk-3.0 network-manager network-manager-openvpn network-manager-openvpn-gnome openvpn
sudo systemctl start NetworkManager
DEST="$HOME/.local/share/vpnbook-kali"
mkdir -p -- "$DEST" "$HOME/.local/share/applications"
install -m 644 app.py "$DEST/app.py"
python3 - "$DEST" <<'PY'
import pathlib, sys
dest = pathlib.Path(sys.argv[1])
# Quote according to Desktop Entry Exec rules, not shell quoting.
arg = str(dest / 'app.py')
for ch in ['\\', '"', '`', '$']:
    arg = arg.replace(ch, '\\' + ch)
arg = arg.replace('%', '%%')
desktop = '[Desktop Entry]\nType=Application\nName=VPNBook Kali\nComment=OpenVPN profil yöneticisi\nExec=/usr/bin/python3 "' + arg + '"\nIcon=network-vpn\nTerminal=false\nCategories=Network;\n'
target = pathlib.Path.home() / '.local/share/applications/vpnbook-kali.desktop'
target.write_text(desktop, encoding='utf-8')
target.chmod(0o755)
PY
echo 'Kurulum tamamlandı. Uygulamalar menüsünden VPNBook Kali uygulamasını açın.'
echo 'Pencereyi kapatabilirsiniz.'
read -r -p 'Çıkmak için Enter tuşuna basın…' _ || true
