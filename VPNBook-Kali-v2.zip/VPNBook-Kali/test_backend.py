"""Backend regression checks; GTK and a live VPN are not required."""
import ast
import os
import subprocess
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

source = ast.parse(Path(__file__).with_name('app.py').read_text(encoding='utf-8'))
nodes = [n for n in source.body if isinstance(n, ast.FunctionDef) and n.name in ('nm', 'connect', 'profiles', 'connect_next')]
scope = {'os': os, 'subprocess': subprocess, 'ENV': {}, 'PREFIX': 'VPNBook • '}
exec(compile(ast.Module(body=nodes, type_ignores=[]), 'backend', 'exec'), scope)


class BackendTests(unittest.TestCase):
    def test_failover_selected_first_then_stop_on_success(self):
        connector = Mock(side_effect=[RuntimeError('unreachable'), None])
        command = Mock(return_value='')
        progress = Mock()
        with patch.dict(scope, connect=connector, nm=command):
            result = scope['connect_next']([('a', 'A'), ('b', 'B'), ('c', 'C')], 'b', 'user', 'secret', progress)
        self.assertEqual(result, ('a', 'A'))
        self.assertEqual([c.args[0] for c in connector.call_args_list], ['b', 'a'])
        self.assertEqual(command.call_args_list[0].args, ('connection', 'down', 'uuid', 'b'))

    def test_all_profiles_fail_once_and_secret_redacted(self):
        connector = Mock(side_effect=RuntimeError('bad secret-example'))
        with patch.dict(scope, connect=connector, nm=Mock(return_value='')):
            with self.assertRaises(RuntimeError) as error:
                scope['connect_next']([('a', 'A'), ('a', 'A'), ('b', 'B')], 'a', 'user', 'secret-example', Mock())
        self.assertEqual(connector.call_count, 2)
        self.assertNotIn('secret-example', str(error.exception))

    def test_no_next_attempt_if_cleanup_fails(self):
        connector = Mock(side_effect=RuntimeError('timeout'))
        command = Mock(side_effect=[RuntimeError('down failed'), 'a'])
        with patch.dict(scope, connect=connector, nm=command):
            with self.assertRaisesRegex(RuntimeError, 'kapatılamadı'):
                scope['connect_next']([('a', 'A'), ('b', 'B')], 'a', 'user', 'secret', Mock())
        self.assertEqual(connector.call_count, 1)

    def test_first_success_does_not_try_others(self):
        connector = Mock()
        with patch.dict(scope, connect=connector):
            self.assertEqual(scope['connect_next']([('a', 'A'), ('b', 'B')], 'a', 'u', 'p', Mock()), ('a', 'A'))
        self.assertEqual(connector.call_count, 1)

    def test_profiles_keep_uuid_and_colons(self):
        response = 'abc:vpn:VPNBook • server:443\ndef:vpn:Other\nghi:802-3-ethernet:Wired'
        with patch.dict(scope, nm=Mock(return_value=response)):
            self.assertEqual(scope['profiles'](), [('abc', 'server:443')])

    def test_secret_only_in_memory_fd_and_closed(self):
        calls = Mock()
        fake = Mock()
        fake.MFD_CLOEXEC = 1
        fake.memfd_create.return_value = 9
        with patch.dict(scope, nm=calls, os=fake):
            scope['connect']('uuid', 'vpnbook', 'secret-example')
        self.assertNotIn('secret-example', repr(calls.call_args_list))
        fake.write.assert_called_once_with(9, b'vpn.secrets.password:secret-example\n')
        self.assertEqual(calls.call_args.kwargs, {'pass_fds': (9,)})
        fake.close.assert_called_once_with(9)

    def test_secret_fd_closed_after_failure(self):
        calls = Mock(side_effect=[None, RuntimeError('denied')])
        fake = Mock(MFD_CLOEXEC=1)
        fake.memfd_create.return_value = 9
        with patch.dict(scope, nm=calls, os=fake):
            with self.assertRaises(RuntimeError):
                scope['connect']('uuid', 'user', 'secret')
        fake.close.assert_called_once_with(9)

    def test_multiline_secret_rejected_before_commands(self):
        calls = Mock()
        with patch.dict(scope, nm=calls):
            with self.assertRaises(ValueError):
                scope['connect']('uuid', 'user', 'bad\nvalue')
        calls.assert_not_called()

    def test_nm_does_not_use_shell_and_propagates_errors(self):
        runner = Mock(return_value=subprocess.CompletedProcess([], 1, '', 'authentication failed'))
        fake = Mock(run=runner)
        with patch.dict(scope, subprocess=fake):
            with self.assertRaisesRegex(RuntimeError, 'authentication failed'):
                scope['nm']('connection', 'up', 'uuid', 'abc')
        args, kwargs = runner.call_args
        self.assertIsInstance(args[0], list)
        self.assertFalse(kwargs.get('shell', False))


if __name__ == '__main__':
    unittest.main()
